package utils;

public enum StatoPartecipazione {
	CONFERMATA, 
	DA_CONFERMARE
}
