package utils;

public enum Sesso {
	MASCHIO, 
	FEMMINA
}
