package utils;

public enum TipoEvento {
	PUBBLICO, 
	PRIVATO
}
